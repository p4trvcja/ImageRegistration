This directory contains a CT and MR scan of the CIRS 057A multi-modality 
abdominal phantom.

NOTE: There are fiducials on the phantom, both in the CT and MR - THEY ARE NOT
      THE SAME FIDUCIALS. The scans were acquired at different times.
